const { MessageEmbed } = require('discord.js');
const db = require('old-wio.db');
const { ownerID } = require("../../owner.json");

module.exports = {
    config: {
        name: "ban",
        category: 'mod',
        aliases: [],
        description: "Ban een gebruiker!",
        usage: "[Naam | Gebruikersnaam | mention | ID] <Reden> (Optioneel)",
    },
    run: async (bot, message, args) => {
        try {
            if (!message.member.hasPermission("BAN_MEMBERS") && !ownerID .includes(message.author.id)) return message.channel.send("**Jij hebt geen perms om mensen te bannen - [BAN_MEMBERS]**");
            if (!message.guild.me.hasPermission("BAN_MEMBERS")) return message.channel.send("**ERROR - [BAN_MEMBERS]**");
            if (!args[0]) return message.channel.send("**voer een naam in!**")

            let banMember = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.guild.members.cache.find(r => r.user.username.toLowerCase() === args[0].toLocaleLowerCase()) || message.guild.members.cache.find(ro => ro.displayName.toLowerCase() === args[0].toLocaleLowerCase());
            if (!banMember) return message.channel.send("**ERROR gebruiker niet gevonden!**");
            if (banMember === message.member) return message.channel.send("**ERROR**")

            var reason = args.slice(1).join(" ");

            if (!banMember.bannable) return message.channel.send("**Ik kan die gebruiker niet kicken!**")
            try {
            message.guild.members.ban(banMember);
            banMember.send(`**Hallo,je bent gebannend ${message.guild.name} voor - ${reason || "Geen reden opgegeven"}**`).catch(() => null)
            } catch {
                message.guild.members.ban(banMember)
            }
            if (reason) {
            var sembed = new MessageEmbed()
                .setColor("GREEN")
                .setDescription(`**${banMember.user.username}** Is verbannen voor: ${reason}`)
            message.channel.send(sembed)
            } else {
                var sembed2 = new MessageEmbed()
                .setColor("GREEN")
                .setDescription(`**${banMember.user.username}** Is verbannen`)
            message.channel.send(sembed2)
            }
            let channel = db.fetch(`modlog_${message.guild.id}`)
            if (channel == null) return;

            if (!channel) return;

            const embed = new MessageEmbed()
                .setAuthor(`${message.guild.name} Modlogs`, message.guild.iconURL())
                .setColor("#ff0000")
                .setThumbnail(banMember.user.displayAvatarURL({ dynamic: true }))
                .setFooter(message.guild.name, message.guild.iconURL())
                .addField("**Moderatie**", "ban")
                .addField("**Banned**", banMember.user.username)
                .addField("**ID**", `${banMember.id}`)
                .addField("**Verbannen door**", message.author.username)
                .addField("**Reden**", `${reason || "**Geen reden**"}`)
                .addField("**Datum**", message.createdAt.toLocaleString())
                .setTimestamp();

            var sChannel = message.guild.channels.cache.get(channel)
            if (!sChannel) return;
            sChannel.send(embed)
        } catch (e) {
            return message.channel.send(`**${e.message}**`)
        }
    }
};