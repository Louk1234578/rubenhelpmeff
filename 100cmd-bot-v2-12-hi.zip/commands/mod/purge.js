const { ownerID } = require('../../owner.json') 

module.exports = {
    config: {
        name: "purge",
        aliases: [],
        category: "mod",
        description: "",
        usage: ""
    },
    run: async (bot, message, args) => {
        if (!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("Je hebt geen perms voor deze command!- [MANAGE_MESSAGES]")
        if (isNaN(args[0]))
            return message.channel.send('**Geef A.U.B op hoeveel berichten u wilt verwijderen!**');

        if (args[0] > 100)
            return message.channel.send("**Geef een getal op van minder dan 100!**");

        if (args[0] < 1)
            return message.channel.send("**Graag een waarde van meer dan 1 invoeren!**");

        message.channel.bulkDelete(args[0])
            .then(messages => message.channel.send(`**Succesvol verwijderd \`${messages.size}/${args[0]}\` Berichten**`).then(msg => msg.delete({ timeout: 5000 }))).catch(() => null)
    }
}