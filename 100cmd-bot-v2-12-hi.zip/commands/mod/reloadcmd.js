const Discord = require("discord.js")
const { readdirSync } = require("fs");
const { OWNER_ID } = require("../../config");
const { MessageEmbed } = require("discord.js");

module.exports = {
    config: {
        name: "reloadmod",
        category: "owner",
        description: "Niet geldig",
        aliases: ['rmod']
    },

    run: async (bot, message, args) => {
        if(message.author.id != OWNER_ID) {
          const rembed = new MessageEmbed()
          .setTitle("Error")
          .setDescription(":x: U bent niet geautoriseerd om deze opdracht te gebruiken, omdat deze beperkt is tot alleen de eigenaar(Bot eigenaar)")
          .setColor("#FF0000")
          .setFooter(message.author.username, bot.user.displayAvatarURL())
          .setTimestamp();
        message.channel.send(rembed).then(m => m.delete({
          timeout: 7500
        })
        );
        } else {
       
        if(!args[0]) return message.channel.send("Graag een command naam gevenop")

        let commandName = args[0].toLowerCase()

        try {
          
          delete require.cache[require.resolve(`./${commandName}.js`)]
          const pull = require(`./${commandName}.js`)
          bot.commands.set(pull.config.name, pull)
          message.channel.send(`Succesvol gereload: \`${commandName}\``)
        }

        catch (e) {
          console.log(e)
          return message.channel.send(`Kan de command niet reloaden: ${commandName} Van moderatiemodule omdat: \n${e}`)
        }

}
      }
} 