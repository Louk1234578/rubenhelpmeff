const { MessageEmbed } = require("discord.js")
const db = require('old-wio.db');

module.exports = {
    config: {
        name: "unmute",
        aliases: ["um"],
        category: 'mod',
        description: "Unmute een gebruiker!!",
        usage: "[Naam | nickname | mention | ID] <reden> (Optioneel)"
    },
    run: async (bot, message, args) => {
        if (!message.member.hasPermission("MANAGE_GUILD")) return message.channel.send("**Je hebt geen perms om mensen te unmute!**");

        if (!message.guild.me.hasPermission("MANAGE_GUILD")) return message.channel.send("**Ik heb geen perms om mensen te unmute!**")
        if (!args[0]) return message.channel.send("**Graag een gebruiker invoeren!**")
        let mutee = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.guild.members.cache.find(r => r.user.username.toLowerCase() === args[0].toLocaleLowerCase()) || message.guild.members.cache.find(ro => ro.displayName.toLowerCase() === args[0].toLocaleLowerCase());
        if (!mutee) return message.channel.send("**Graag een geldig gebruiker invoeren**");

        let reason = args.slice(1).join(" ");

        let muterole;
        let dbmute = await db.fetch(`muterole_${message.guild.id}`);
        let muteerole = message.guild.roles.cache.find(r => r.name === "muted")

        if (!message.guild.roles.cache.has(dbmute)) {
            muterole = muteerole
        } else {
            muterole = message.guild.roles.cache.get(dbmute)
        }
      
        let rolefetched = db.fetch(`muteeid_${message.guild.id}_${mutee.id}`)
        if (!rolefetched) return;

        if (!muterole) return message.channel.send("**Er is geen 'muted' rol gevonden in deze server!**")
        if (!mutee.roles.cache.has(muterole.id)) return message.channel.send("**Gebruiker was niet gemuted!**")
        try {
        mutee.roles.remove(muterole.id).then(() => {
            mutee.send(`**Hallo,je bent geunmuted door${message.guild.name} voor ${reason || "GEEN REDEN"}**`).catch(() => null)
            let roleadds = rolefetched
            if (!roleadds) return;
            mutee.roles.add(roleadds)
        })
        } catch {
            let roleadds2 = rolefetched
            if (!roleadds2) return;
            mutee.roles.add(roleadds2)                            
          }
            const sembed = new MessageEmbed()
                .setColor("GREEN")
                .setDescription(`${mutee.user.username} Is succesvol geunmuted.`)
            message.channel.send(sembed);
        



    }
}