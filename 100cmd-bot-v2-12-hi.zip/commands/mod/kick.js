const { MessageEmbed } = require('discord.js');
const db = require('old-wio.db');

module.exports = {
	config: {
		name: 'kick',
		category: 'mod',
		description: 'Kick een gebruiker',
		accessableby: 'Administrator',
		usage: '[Naam | Gebruikersnaam | mention | ID] <reden> (Optioneel)',
		aliases: []
	},
	run: async (bot, message, args) => {
		try {
			if (!message.member.hasPermission('KICK_MEMBERS'))
				return message.channel.send(
					'**Jij hebt geen perms om mensen te kicken! - [KICK_MEMBERS]**'
				);
			if (!message.guild.me.hasPermission('KICK_MEMBERS'))
				return message.channel.send(
					'**ERROR ,geef de bot perms - [KICK_MEMBERS]**'
				);

			if (!args[0]) return message.channel.send('**Voer een gebruiker in om te kicken!**');
			
			let reason = args.slice(1).join(" ");

			var kickMember =
				message.mentions.members.first() ||
				message.guild.members.cache.get(args[0]) ||
				message.guild.members.cache.find(
					r => r.user.username.toLowerCase() === args[0].toLocaleLowerCase()
				) ||
				message.guild.members.cache.find(
					ro => ro.displayName.toLowerCase() === args[0].toLocaleLowerCase()
				);
			if (!kickMember)
				return message.channel.send('**Gebruiker niet in de guilde!**');

			if (kickMember.id === message.member.id)
				return message.channel.send('**Je kan jezelf niet kicken!**');
				   if (kickMember.roles.highest.position >= message.member.roles.highest.position && message.author.id !== message.guild.owner.id) {
            return message.channel.send(":x: | **Je kunt dit lid niet kicken, omdat je rol lager is dan die lidrol.**")
        }

			if (kickMember.kickable) {
				const sembed2 = new MessageEmbed()
					.setColor('RED')
					.setDescription(
						`**Je bent gekicked door ${message.guild.name} voor - ${reason ||
							'Geen Reden'}**`
					)
					.setFooter(message.guild.name, message.guild.iconURL());
				kickMember
					.send(sembed2);
				kickMember.kick();
			} else {
			  return message.channel.send(":x: | **Ik kan deze gebruiker niet kicken, zorg ervoor dat de gebruikersrol lager is dan mijn rol.**");
			}
			if (reason) {
				var sembed = new MessageEmbed()
					.setColor('GREEN')
					.setDescription(
						`**${kickMember.user.username}** Is gekicked voor ${reason}`
					);
				message.channel.send(sembed);
			} else {
				var sembed2 = new MessageEmbed()
					.setColor('GREEN')
					.setDescription(`**${kickMember.user.username}** Is gekicked`);
				message.channel.send(sembed2);
			}
			let channel = db.fetch(`modlog_${message.guild.id}`);
			if (!channel) return;

			const embed = new MessageEmbed()
				.setAuthor(`${message.guild.name} Modlogs`, message.guild.iconURL())
				.setColor('#ff0000')
				.setThumbnail(kickMember.user.displayAvatarURL({ dynamic: true }))
				.setFooter(message.guild.name, message.guild.iconURL())
				.addField('**Moderatie*', 'Kick')
				.addField('**Gebruiker gekicked**', kickMember.user.username)
				.addField('**Gekicked door:**', message.author.username)
				.addField('**Reden**', `${reason || '**Geen reden**'}`)
				.addField('**Datum**', message.createdAt.toLocaleString())
				.setTimestamp();

			var sChannel = message.guild.channels.cache.get(channel);
			if (!sChannel) return;
			sChannel.send(embed);
		} catch (e) {
			return message.channel.send(`**${e.message}**`);
		}
	}
};
