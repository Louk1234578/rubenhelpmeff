const db = require("old-wio.db");

module.exports = {
  config: {
  name: "resetwarns",
  aliases: ["rwarns"],
  category: "mod",
  usage: "rwarns <@user>",
  description: "Reset warns",
  },
  run: async (bot, message, args) => {
    
    
    if(!message.member.hasPermission("ADMINISTRATOR")) {
      return message.channel.send("ERROR jij hebt geen perms voor deze command je hebt : ADMINISTRATOR perms nodig!")
    }
    
    const user = message.mentions.members.first() 
    
    if(!user) {
    return message.channel.send("ERROR")
    }
    
    if(message.mentions.users.first().bot) {
      return message.channel.send("ERROR")
    }
    
    if(message.author.id === user.id) {
      return message.channel.send("ERROR")
    }
    
    let warnings = await db.fetch(`warnings_${message.guild.id}_${user.id}`)
    
    if(warnings === null) {
      return message.channel.send(`${message.mentions.users.first().username} Heeft geen warns`)
    }
    
   await db.delete(`warnings_${message.guild.id}_${user.id}`);
    user.send(`Al jou warns zijn gereset door ${message.author.username} van ${message.guild.name}`)
    await message.channel.send(`Alle waarschuwingen zijn gereset van: ${message.mentions.users.first().username}`)
    
  
    
}
}
