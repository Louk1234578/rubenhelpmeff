const { MessageEmbed } = require('discord.js');
const db = require("old-wio.db");

module.exports = {
    config: {
        name: "warn",
        description: "warn members",
        category: 'mod',
        usage: "m/warn <mention Gebruiker/Gebruiker id> [Reden]",
        aliases: []
    },
    run: async (bot, message, args) => {
        let warnPermErr = new MessageEmbed()
        .setTitle("**User Permission Error!**")
        .setDescription("**Sorry je hebt geen perms om deze command te gebruiken! ❌**")
            if(!message.channel.permissionsFor(message.member).has(['MANAGE_MESSAGES'])) return message.channel.send(warnPermErr);
    
            let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
            if(!member) return message.reply("Graag een geldige gebruiker opgeven in de server om te warnen!");
        
            let reason = args.slice(1).join(' ');
            if(!reason) reason = "(Geen reden opgegeven)";
            
            let warnings = await db.fetch(`warnings_${message.guild.id}_${member.id}`)
            
            if(warnings === 3) {
      return message.channel.send(`${member} De gebruiker heeft de limiet van de warnings te pakken(limiet:3)`)
    }
    
    if(warnings === null) {
            
            db.set(`warnings_${message.guild.id}_${member.id}`, 1)
            
            member.send(`Je bent gewarned door: <${message.author.username}> Voor de reden: ${reason}`)
            .catch(error => message.channel.send(`Sorry <${message.author}> Ik kon niet waarschuwen vanwege : ${error}`));
            let warnEmbed = new MessageEmbed()
            .setTitle("**__Warn Report__**")
            .setDescription(`**<@${member.user.id}>Is gewarned door <@${message.author.id}>**`)
            .addField(`**Reden:**`, `\`${reason}\``)
            .addField(`**Actie:**`, `\`Warn\``)
            .addField(`**Moderator:**`, `${message.author}`)

            message.channel.send(warnEmbed).then(msg => msg.delete({
              timeout: 5000
            }));
    } else if (warnings !== null) {
      db.add(`warnings_${message.guild.id}_${member.id}`, 1)
      member.send(`Je bent gewarned door <${message.author.username}>Voor deze reden:: ${reason}`)
            .catch(error => message.channel.send(`Sorry <${message.author}> Ik kon niet waarschuwen vanwege : ${error}`));
            let ddEmbed = new MessageEmbed()
            .setTitle("**__Warn Report__**")
            .setDescription(`**<@${member.user.id}> IS gewarned door: <@${message.author.id}>**`)
            .addField(`**Reden:**`, `\`${reason}\``)
            .addField(`**Actie:**`, `\`Warn\``)
            .addField(`**Moderator:**`, `${message.author}`)

            message.channel.send(ddEmbed)
    }

    }
}