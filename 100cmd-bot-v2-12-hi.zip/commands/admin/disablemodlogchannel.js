const db = require('old-wio.db');

module.exports = {
    config: {
        name: "disablemodlogchannel",
        aliases: ['dmc', 'disablem', 'disablemodlog'],
        category: 'admin',
        description: 'Disables Server Modlog Channel',
        usage: '[Kanaal Naam | Kanaal mention | Kanaal ID]',
        accessableby: 'Administrators'
    },
    run: async (bot, message, args) => {
        if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send("**Je hebt geen perms - [ADMINISTRATOR]**")

        try {
            let a = db.fetch(`modlog_${message.guild.id}`)

            if (!a) {
                return message.channel.send('**Geen log kanaal gevonden!**')
            } else {
                let channel = message.guild.channels.cache.get(a)
                bot.guilds.cache.get(message.guild.id).channels.cache.get(channel.id).send("**Welkom kanaal uitgeschakeld**")
                db.delete(`modlog_${message.guild.id}`)

                message.channel.send(`*Modlog kanaal succesvol uitgeschakeld in \`${channel.name}\`**`)
            }
            return;
        } catch {
            return message.channel.send("**Fout - `Ontbrekende machtigingen of kanaal bestaat niet`**")
        }
    }
}