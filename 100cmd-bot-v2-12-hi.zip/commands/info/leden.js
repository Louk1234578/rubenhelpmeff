const Discord = require("discord.js");

module.exports = {
    config: {
  name: "leden",
  aliases: ["le"],
  description: "Leden Almelo Roleplay",
  usage: "",
  category: "info",
    },
 run: async (bot, message, args) => {
  let user;

if (message.mentions.users.first())
 {
user = message.mentions.users.first();

} else if (args[0]) {

user = message.guild.members.cache.get(args[0]).user;

} else {
user = message. author;
}



let avatar = user.displayAvatarURL ({size: 4096, dynamic: true});

const embed = new Discord.MessageEmbed()

.setTitle(`Leden aantal:`)
.addField('Leden', message.guild.memberCount)
.setColor("#FFA500");

return message.channel.send(embed);
}
};