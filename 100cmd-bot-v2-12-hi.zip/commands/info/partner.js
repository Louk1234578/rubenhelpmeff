const Discord = require("discord.js");

module.exports = {
    config: {
  name: "partner",
  aliases: ["pt"],
  description: "Partnertekst",
  usage: "",
  category: "info",
    },
 run: async (bot, message, args) => {
  let user;

if (message.mentions.users.first())
 {
user = message.mentions.users.first();

} else if (args[0]) {

user = message.guild.members.cache.get(args[0]).user;

} else {
user = message. author;
}



let avatar = user.displayAvatarURL ({size: 4096, dynamic: true});

const embed = new Discord.MessageEmbed()

.setTitle(`partnertekst Almelo Roleplay`)
.setDescription(`Hey,
Wij zijn Almelo Roleplay.
Een net nieuwe Roleplay Game.
We zijn momenteel druk bezig met de game en hopen dan ook dat die snel uitkomt.
We hebben alleen nog enkele dingen nodig:
- Developers.
- Staff
- Leden
Kan jij een van deze dingen join dan zeker!
Bij de 300 leden een giveaway en sollicitaties open!

Mvg,

Staff team Almelo Roleplay.
Linkjes:
Discord:
 https://discord.gg/5BRxVvfb6f
Sneak peeks:
 https://media.discordapp.net/attachments/893655054085652481/901179676976898118/unknown.png?width=1440&height=524
https://media.discordapp.net/attachments/893655054085652481/898913889067077652/unknown.png?width=1202&height=676
https://media.discordapp.net/attachments/893655054085652481/896770164580819034/unknown.png?width=1200&height=676
https://media.discordapp.net/attachments/893655054085652481/901816993395650640/unknown.png?width=1440&height=526 `) 
.setColor("RANDOM");

return message.channel.send(embed);
}
};