const Discord = require("discord.js");

module.exports = {
    config: {
  name: "partnerinfo",
  aliases: ["pi"],
  description: "Partnerinfo Almelo Roleplay",
  usage: "Avatar [@user | user ID]",
  category: "info",
    },
 run: async (bot, message, args) => {
  let user;

if (message.mentions.users.first())
 {
user = message.mentions.users.first();

} else if (args[0]) {

user = message.guild.members.cache.get(args[0]).user;

} else {
user = message. author;
}



let avatar = user.displayAvatarURL ({size: 4096, dynamic: true});

const embed = new Discord.MessageEmbed()

.setTitle(`partnerinfo Almelo Roleplay`)
.setDescription(`Partner eisen Almelo Roleplay
- Minimaal 25 leden.
- Onder de 75 leden everyone tag.
- Onder de 100 leden here tag.
- Geen leakers/ raiders in het staff team.
- U plaatst zelf het partner bericht in de discord.
- Als u leaved zal het bericht verwijderd worden.
 ©️ Almelo Roleplay`) 
.setColor("RANDOM");

return message.channel.send(embed);
}
};