const db = require("old-wio.db");
const { MessageEmbed } = require("discord.js");

module.exports = {
  config: {
    name : 'removeafk',
    aliases: ["rafk"],
    category: "utility",
    description: "haal je afk weg",
    usage: "rafk",
  },
    run : async(bot, message, args) => {
        const check = await db.fetch(`afk-${message.author.id}+${message.guild.id}`)
        if(check === true) {
          message.channel.send("ERROR je zat niet in een afk");
        } else {
        const embed = new MessageEmbed()
        .setDescription(`Je afk is verwijderd!`)
        .setColor("GREEN")
        .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic : true }))
        .setTimestamp();
        message.channel.send(embed)                }
    }
};