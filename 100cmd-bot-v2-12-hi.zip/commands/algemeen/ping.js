const Discord = require("discord.js");

module.exports = {
    config: {
        name: "ping",
        description: "Ping van de bot",
        category: 'utility',
        usage: "ping",
        example: "ping",
        aliases: ['']
    },
    run: async (bot, message, args) => {
        let start = Date.now();
  
  message.channel.send({embed: {description: "🔍 Ik denk dat mijn ping hoog is ", color: "RANDOM"}}).then(m => {
    
    let end = Date.now();
    
    let embed = new Discord.MessageEmbed()
    .setAuthor("Pong!", message.author.avatarURL({ dynamic: true }))
    .addField("API Latency", Math.round(bot.ws.ping) + "ms", true)
    .addField("Berichten Latency", end - start + "ms")
    .setColor("RANDOM");
    m.edit(embed).catch(e => message.channel.send(e));
    
  });
    }
};