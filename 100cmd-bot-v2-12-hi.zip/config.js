exports.PREFIX = "!";
exports.OWNER_ID = "708577566419845161";
exports.Owner_Name = "Loukmane#0186";